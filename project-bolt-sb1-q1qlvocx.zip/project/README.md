# Izzy Makes Bots

A modern, responsive website showcasing AI automation services including customer support chat agents, appointment scheduling, website design, and AI app development.

## 🚀 Features

- **Responsive Design**: Optimized for mobile, tablet, and desktop viewing
- **Modern UI**: Built with React, TypeScript, and Tailwind CSS
- **3D Graphics**: Interactive Spline 3D viewer integration
- **Performance Optimized**: Fast loading with Vite build system
- **Accessible**: WCAG compliant design principles

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Build Tool**: Vite
- **Icons**: Lucide React
- **3D Graphics**: Spline Viewer
- **Deployment**: GitHub Pages

## 📱 Responsive Design

The website is fully responsive with optimized layouts for:

- **Mobile (< 640px)**: Single column layout, touch-friendly navigation
- **Tablet (640px - 1024px)**: Two-column grids, medium text sizes
- **Desktop (> 1024px)**: Multi-column layouts, large typography

## 🎨 Services Offered

1. **AI Customer Support Chat Agents**
   - 24/7 automated customer support
   - Natural language processing
   - Multi-language support

2. **AI Appointment Scheduling**
   - Automated booking system
   - Calendar integration
   - SMS/email confirmations

3. **Website Design & Development**
   - Responsive mobile-first design
   - SEO optimization
   - E-commerce integration

4. **AI App Development**
   - Custom AI model development
   - Workflow automation
   - Scalable cloud deployment

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/izzy-makes-bots.git
cd izzy-makes-bots
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser

### Building for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## 📦 Deployment

### GitHub Pages (Automatic)

This project is configured for automatic deployment to GitHub Pages:

1. Push to the `main` branch
2. GitHub Actions will automatically build and deploy
3. Site will be available at `https://yourusername.github.io/izzy-makes-bots/`

### Manual Deployment

You can deploy the `dist` folder to any static hosting service:

- Netlify
- Vercel
- AWS S3
- Firebase Hosting

## 🔧 Configuration

### Base URL

The base URL is automatically configured for GitHub Pages. For other deployments, update `vite.config.ts`:

```typescript
export default defineConfig({
  base: '/your-repo-name/', // For GitHub Pages
  // base: '/', // For custom domain or root deployment
});
```

### Environment Variables

Create a `.env` file for local development:

```env
VITE_SITE_URL=http://localhost:5173
```

## 📞 Contact Information

- **Phone**: (682) 472-8400
- **Email**: israel.medrano218@icloud.com

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- [React](https://reactjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Lucide Icons](https://lucide.dev/)
- [Spline](https://spline.design/)
- [Vite](https://vitejs.dev/)